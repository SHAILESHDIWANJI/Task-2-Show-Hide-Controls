import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrl: './form.component.scss'
})
export class FormComponent implements OnInit,OnChanges {

contactInput:any=''

 ngOnInit(): void {
   console.log(this.contactInput);
 }
 ngOnChanges(changes: SimpleChanges): void {
   console.log(changes);
   console.log(this.contactInput);
 }
}
