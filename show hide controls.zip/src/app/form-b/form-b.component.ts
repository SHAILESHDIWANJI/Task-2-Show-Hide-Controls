import { Component } from '@angular/core';

@Component({
  selector: 'app-form-b',
  templateUrl: './form-b.component.html',
  styleUrl: './form-b.component.scss'
})
export class FormBComponent {
  contactRadio=''
}
